"""
Пороги и настройки. Если логика будет врать — крутим ТОЛЬКО здесь.
Тариф: Twelve Data, 337 кредитов/мин.
"""
import os

PAIRS = [
    "EUR/USD",
    "GBP/USD",
    "USD/JPY",
    "USD/CHF",
    "AUD/USD",
    "NZD/USD",
    "USD/CAD",
]

CURRENCIES = ["USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD"]

# Старший → младший. Сигнал идёт сверху вниз.
TIMEFRAMES = [
    {"key": "W1", "api": "1week", "label": "Неделя", "candles": 100, "ttl_min": 30},
    {"key": "D1", "api": "1day", "label": "День", "candles": 200, "ttl_min": 15},
    {"key": "H4", "api": "4h", "label": "4 часа", "candles": 250, "ttl_min": 5},
    {"key": "H1", "api": "1h", "label": "Час", "candles": 250, "ttl_min": 1},
    {"key": "M15", "api": "15min", "label": "15 минут", "candles": 250, "ttl_min": 1},
    {"key": "M5", "api": "5min", "label": "5 минут", "candles": 250, "ttl_min": 1},
]

STRENGTH_TF = "H1"
# Сила = движение за последнюю ЗАКРЫТУЮ часовую свечу.
# Сила по нескольким закрытым H1, а не по одному шумному бару.
STRENGTH_LOOKBACK = 4
STRENGTH_RANK_JUMP = 2
# Автосообщение — только когда закрылась новая H1, не чаще раза за эту свечу.
STRENGTH_REPORT_EVERY_HOURS = 1
# Navigator: H1 basket-strength dynamics are contextual, never a standalone veto.
NAVIGATOR_STRENGTH_DYNAMICS_SAMPLES = 4
NAVIGATOR_STRENGTH_DYNAMICS_NOISE = 0.015
NAVIGATOR_STRENGTH_CROSS_CONFIRM = 0.025
# Порог силы пары для decide_signal / старого маршрута /now.
# Финальный вход Master Direction использует MASTER_STRENGTH_MIN_GAP (ниже).
PAIR_STRENGTH_MIN = 0.20
# Лидер брифинга не выбирается при практически равной силе валют.
BRIEFING_LEADER_MIN_STRENGTH_GAP = 0.05

SCAN_EVERY_MINUTES = 1
# Latency policy: scan every minute so a freshly CLOSED M5/M15 candle is processed
# promptly; this is still well below the configured paid-plan request budget.
# Полный скан торгует только при синхронной корзине 7 мажоров на рабочих ТФ.
MARKET_REQUIRE_COMPLETE = True
MARKET_REQUIRED_TFS = ("H1", "M15", "M5", "H4")
MARKET_MIN_CLOSED_H1 = 20
# Если доля сканеров с исключением выше порога — торговые карточки в этот тик не шлём.
SCAN_FAIL_ABORT_RATIO = 0.35
# Автоматические сканы и уведомления: только понедельник–пятница.
# Номера дней Python: понедельник=0, воскресенье=6.
AUTOMATIC_WEEKDAYS_ONLY = True
AUTOMATIC_ACTIVE_WEEKDAYS = (0, 1, 2, 3, 4)
# 337 кредитов/мин. Полный скан = 6 batch ≈ 42 кредита. Запас большой.
REQUEST_PAUSE_SEC = 0.08
PAID_PLAN = True
PLAN_NAME = "337"

ZIGZAG_PCT = {
    "W1": 1.20,
    "D1": 0.70,
    "H4": 0.35,
    "H1": 0.18,
    "M15": 0.12,
    "M5": 0.08,
}
ZIGZAG_MIN_BARS = 3
# Ансамбль ZigZag: быстрый / базовый / медленный масштабы. Итоговое
# направление разрешается только при согласии минимум 2 из 3.
ZIGZAG_ENSEMBLE_FACTORS = (0.72, 1.00, 1.45)
# Адаптивный ZigZag: процентный порог дополняется текущей волатильностью ATR.
ZIGZAG_ADAPTIVE_PCT_FACTOR = 0.55
ZIGZAG_MIN_MOVE_ATR = 0.55
ZIGZAG_EARLY_M15_BARS = 3
ZIGZAG_EARLY_M5_CONFIRM_BARS = 3
ZIGZAG_EARLY_MIN_BODY_ATR = 0.45
ZIGZAG_EARLY_MIN_STRENGTH_GAP = 0.05
SIGNAL_BLOCK_OPPOSITE_H4_ZIGZAG = False
DXY_IMPULSE_MIN_CHANGE_PCT = 0.05
DXY_IMPULSE_MIN_ADX = 25

ADX_PERIOD = 14
ADX_TREND = 22
EMA_FAST = 21
EMA_SLOW = 50

FVG_NEAR_ATR = 1.2
ATR_PERIOD = 14

# HTF IRL (Internal Range Liquidity): внутренний контекст Master Direction.
# Не создаёт отдельные сигналы и не дублирует Imbalance/FVG.
HTF_IRL_ENABLED = True
HTF_IRL_TIMEFRAMES = ("H4", "D1")
HTF_IRL_FVG_LOOKBACK = 80
HTF_IRL_MIN_RANGE_ATR = 1.5
HTF_IRL_NEAR_ATR = 1.25
HTF_IRL_ALIGN_BONUS = 5
HTF_IRL_CONFLICT_PENALTY = 3

# IMD (Intermarket Divergence): внутренний межрыночный контроль.
# Сравнивает закрытые H1/H4 семи USD-major; самостоятельных уведомлений нет.
IMD_ENABLED = True
IMD_H1_LOOKBACK = 3
IMD_H4_LOOKBACK = 2
IMD_MIN_PEERS = 2
IMD_MAJORITY_MARGIN = 1
IMD_MIN_MOVE_PCT = 0.025
IMD_MIN_MOVE_ATR = 0.20
IMD_ALIGN_BONUS = 4
IMD_CONFLICT_PENALTY = 4

# IDM (Inducement): один внутренний SMC-фильтр качества входа.
# Рабочий детектор — idm.py (H1/H4 swing). inducement.py только алиас.
IDM_ENABLED = True
IDM_NEAR_ATR = 1.25
IDM_SWEEP_BONUS = 4
IDM_UNSWEPT_PENALTY = 3
IDM_ALIGN_BONUS = IDM_SWEEP_BONUS
IDM_CONFLICT_PENALTY = IDM_UNSWEPT_PENALTY
IDM_LOOKBACK = 40

HTF_KEYS = ["W1", "D1", "H4"]
HTF_MIN_AGREE = 2

LTF_KEYS = ["H1", "M15", "M5"]
LTF_MIN_AGREE = 2

SIGNAL_COOLDOWN_HOURS = 6
# Independent setups must not be suppressed for six hours just because pair/side match.
# Delivery cooldown is scoped by source family; durable event IDs still block exact duplicates.
SIGNAL_SETUP_COOLDOWN_HOURS = 1.5
# Единый бюджет для всех торговых модулей после одной закрытой H1.
# Часовой брифинг и новостные сообщения в этот лимит не входят.
# Верхний предел НОВЫХ торговых карточек модулей за одну закрытую H1
# (не обещание «будет ровно N»). 0 = без лимита (опасно: флуд).
# Обязательные AMD / пробой уровня в этот бюджет не входят.
# После склейки одной идеи на пару общий числовой потолок отключён: каждый уникальный прошедший сигнал может быть доставлен.
MAX_MODULE_ALERTS_PER_H1 = 0
SIGNAL_JOURNAL_ENABLED = True
# Legacy journal still records outcomes, but its separate daily/weekly Telegram summaries are disabled.
# Daily Calibration Report is the single statistical Telegram report.
SIGNAL_JOURNAL_REPORTS_ENABLED = False
# Passive calibration dataset; never sends Telegram messages or changes scanner decisions.
DECISION_JOURNAL_ENABLED = True
# Passive replay/calibration: observe outcomes only; never changes live verdicts.
REPLAY_CALIBRATION_ENABLED = True
REPLAY_JOURNAL_SCAN_LIMIT = 4000
# One compact end-of-trading-day calibration report; reporting only.
DAILY_CALIBRATION_REPORT_ENABLED = True
DAILY_CALIBRATION_REPORT_HM = (22, 35)
JOURNAL_TARGET_ATR = 1.0
JOURNAL_INVALIDATION_ATR = 0.75
# Время Europe/Amsterdam; скан отправит отчёт в ближайший 5-минутный запуск.
# Один окончательный отчёт утром за предыдущий торговый день (Europe/Amsterdam).
JOURNAL_DAILY_REPORT_HM = (9, 10)
JOURNAL_WEEKLY_REPORT_HM = (22, 30)
MASTER_DIRECTION_ENABLED = True
MASTER_STRENGTH_MIN_GAP = 0.05
MASTER_MIN_QUALITY = 78
MASTER_REQUIRE_MODULE_TRIGGER = True
MASTER_MAX_SIGNALS_PER_H1 = 0
# Направленная торговая карточка в чат только после прохождения Master.
MASTER_REQUIRE_FOR_DELIVERY = True
# Echo — сессионная информационная проекция. В Master Direction не вмешивается.
ECHO_ENABLED = True
ECHO_SESSION_MODE = True  # прогноз от текущей до следующей сессии
ECHO_HORIZONS_H1 = (1, 2, 4, 8)
ECHO_MIN_ANALOGS = 30
ECHO_MAX_ANALOGS = 50
ECHO_MAX_DISTANCE = 2.6
ECHO_MIN_CONFIDENCE = 0.62
ECHO_CONTEXT_MIN_MARGIN = 8
# Флаг сохранён для совместимости; торговый veto через Echo сейчас выключен.
ECHO_BLOCK_OPPOSITE_CONFIDENCE = 0.75
# Самостоятельный Echo: отдельная карточка с графиком, вне торгового лимита.
ECHO_STANDALONE_ENABLED = False
ECHO_ALERT_MIN_CONFIDENCE = 0.72
ECHO_CHART_CANDLES = 40
ECHO_CONTEXT_MIN_SCORE = 0.68
ECHO_STRENGTH_MIN_GAP = 0.04
# Сессионные Эхо + Next Pivot: один парный media-group (2 изображения) на каждую из семи пар.
# Они не входят в лимит обычных торговых уведомлений.
SESSION_PROJECTIONS_ENABLED = True
# Если Railway пропустил открытие сессии, недоставленные карточки догоняются
# при ближайшем сканировании в пределах той же сессии.
SESSION_PROJECTIONS_CATCH_UP = True
SESSION_PROJECTIONS_OPEN_WINDOW_MIN = 20
# Почасовые одиночные карточки отключены, чтобы не дублировать сессионные.
ECHO_HOURLY_ENABLED = False
NEXT_PIVOT_HOURLY_ENABLED = False
# Next Pivot Projection — информационная зона возможного следующего экстремума.
NEXT_PIVOT_ENABLED = True
NEXT_PIVOT_MIN_SAMPLES = 8
NEXT_PIVOT_MIN_PROBABILITY = 65
NEXT_PIVOT_MIN_ZONE_ATR = 0.25
NEXT_PIVOT_NEAR_ATR = 0.55
# Ранний локальный сценарий: только завершённый AMD, подтверждённые M15/M5
# и ещё не более 45% уже пройденного структурного маршрута.
LOCAL_AMD_EARLY_ENABLED = True
LOCAL_AMD_MIN_STRENGTH_GAP = 0.08
LOCAL_AMD_MAX_PROGRESS_PCT = 45
# Новая карточка Навигатора допустима только в ранней части всего маршрута
# от anchor до последней доступной структурной цели TR3.
SIGNAL_INITIAL_MAX_PROGRESS_PCT = 35
# Levels breakout is a time-sensitive market fact: never let the hourly module
# budget hide it. Navigator still rejects a late NEW entry after TR1 progress.
LEVEL_BREAKOUT_MANDATORY_DELIVERY = True
LEVEL_NEWS_CONTEXT_ENABLED = True
LEVEL_NEWS_HIGH_WINDOW_MINUTES = 60
LEVEL_NEWS_MEDIUM_WINDOW_MINUTES = 30
# Не присылать предположительные предупреждения о близости к цели:
# только фактическое достижение TR1/TR2/TR3 или подтверждённая отмена.
SIGNAL_NEAR_TARGET_ALERTS = False
# Откат внутри уже присланного сигнала: предупреждение, не новый вход.
SIGNAL_PULLBACK_ALERTS = True
SIGNAL_PULLBACK_MIN_RETRACE_PCT = 8
SIGNAL_PULLBACK_DEEP_PCT = 35
SIGNAL_PULLBACK_DONE_RECOVER_PCT = 3
MASTER_NEWS_BLOCK_BEFORE_MINUTES = 60
MASTER_NEWS_BLOCK_AFTER_MINUTES = 30

LOCAL_TZ_NAME = "Europe/Amsterdam"
SESSIONS = [
    {"key": "ASIA", "name": "АЗИАТСКАЯ СЕССИЯ", "start_hm": "00:00"},
    {"key": "EUROPE", "name": "ЕВРОПЕЙСКАЯ СЕССИЯ", "start_hm": "09:00"},
    {"key": "AMERICA", "name": "АМЕРИКАНСКАЯ СЕССИЯ", "start_hm": "15:00"},
]
# Публичный /indices Twelve Data не содержит DXY; time_series на тарифе часто отдаёт DXY.
# Рабочий тикер можно задать в ENV, не меняя код.
DXY_SYMBOL = (os.getenv("DXY_SYMBOL") or "DXY").strip() or "DXY"
USDSEK_SYMBOL = "USD/SEK"
DXY_SEK_MAX_LAG_HOURS = int(os.getenv("DXY_SEK_MAX_LAG_HOURS") or "2")
DXY_MIN_PRICE = 50.0
DXY_MAX_PRICE = 200.0
BRIEFING_ENABLED = True
# Часовой брифинг выключен: одна простыня на открытие Азии / Европы / Америки.
BRIEFING_SESSION_ONLY = True
BRIEFING_SESSION_CATCH_UP = True
NEWS_WARN_MINUTES = 60
NEWS_CACHE_MAX_AGE_HOURS = 168
# Forex Factory updates the weekly file about hourly and rate-limits
# more than ~2 downloads / 5 minutes / IP. Scan+briefing used to hit it
# every minute and then saw HTML 429 as "calendar does not exist".
NEWS_FETCH_MIN_MINUTES = 45
# CPI — отдельный строгий фундаментальный слой.
# Сюрприз измеряется в процентных пунктах (например 3.2 vs 3.1 = +0.1 п.п.).
CPI_MIN_SURPRISE_PP = 0.05
CPI_BLOCK_BEFORE_MINUTES = 60
CPI_BLOCK_AFTER_MINUTES = 30
BRIEFING_OPEN_WINDOW_MIN = 15
LEVELS_ENABLED = True
LEVEL_NOTIFY_NEW = False
# Не объединять далёкие уровни в одну чрезмерно широкую торговую зону.
LEVEL_MAX_ZONE_H1_ATR = 3.0
LEVEL_MAX_ZONE_PIPS = 45
LEVEL_EVENT_COOLDOWN_MINUTES = 55
LEVEL_EXACT_EVENT_HISTORY = 1500
LEVEL_MIN_EVENT_QUALITY = 74
LEVEL_MIN_EVENT_CONFIDENCE = 70
LEVEL_CHART_IMAGES_ENABLED = True
LEVEL_CHART_LOOKBACK = 72
# Отбой отправляется только после следующей H1 и при поддержке силы валют.
LEVEL_BOUNCE_REQUIRE_FOLLOW_THROUGH = True
LEVEL_BOUNCE_MIN_STRENGTH_GAP = 0.05
LEVEL_FALSE_BREAK_MIN_STRENGTH_GAP = 0.05
# Связывать противоположные подтверждённые реакции одной пары внутри дня.
LEVEL_DIRECTION_MEMORY_HOURS = 12
# Levels remain context-first: touch alone is never a LONG/SHORT fact.
LEVEL_TOUCH_IS_SIGNAL = False
ZIGZAG_SCANNER_ENABLED = True
ZIGZAG_CHART_IMAGES_ENABLED = True
PATTERNS_ENABLED = True
# Impulse Displacement: shared confirmation layer (not FVG and not Disbalance/BOS).
DISPLACEMENT_ENABLED = True
DISPLACEMENT_MIN_BODY_ATR = 1.00
DISPLACEMENT_MIN_BODY_RATIO = 0.65
DISPLACEMENT_MIN_CLOSE_EFFICIENCY = 0.78
DISPLACEMENT_MIN_RANGE_ATR = 1.15
DISPLACEMENT_MIN_SCORE = 72

DISBALANCE_ENABLED = True
DISBALANCE_CHART_IMAGES_ENABLED = True
DISBALANCE_MIN_BODY_ATR = 1.25
DISBALANCE_MIN_BODY_RATIO = 0.62
DISBALANCE_BOS_LOOKBACK = 12
DISBALANCE_MIN_STRENGTH_GAP = 0.06
DISBALANCE_MIN_QUALITY = 76
IMBALANCE_ENABLED = True
IMBALANCE_CHART_IMAGES_ENABLED = True
IMBALANCE_MIN_GAP_ATR = 0.08
IMBALANCE_MIN_STRENGTH_GAP = 0.05
IMBALANCE_MIN_QUALITY = 74
# FVG должен быть создан реальным displacement, а не случайным микрогэпом.
IMBALANCE_MIN_IMPULSE_ATR = 0.80
IMBALANCE_MIN_BODY_RATIO = 0.60
# Structural FVG: повышенный вес только если FVG рождается после реальной смены структуры + displacement.
# Это НЕ отдельное семейство/голос и не делает обычный FVG недействительным.
IMBALANCE_STRUCTURAL_SWING_BARS = 4
IMBALANCE_STRUCTURAL_CLOSE_BUFFER_ATR = 0.05
IMBALANCE_STRUCTURAL_FVG_BONUS = 7
# Ретест считается подтверждённым только после заметного входа в FVG и свечи-отказа.
IMBALANCE_RETEST_MIN_PENETRATION = 0.20
IMBALANCE_RETEST_MIN_BODY_RATIO = 0.45
# Consolidation Zone — отдельный событийный детектор. Зону ведёт молча;
# наружу отправляет только подтверждённый LONG/SHORT выход, чтобы не спамить.
CONSOLIDATION_ZONE_ENABLED = True
CONSOLIDATION_CHART_IMAGES_ENABLED = True
CONSOLIDATION_RANGE_BARS = 14
CONSOLIDATION_MIN_WIDTH_ATR = 0.65
CONSOLIDATION_MAX_WIDTH_ATR = 3.20
CONSOLIDATION_MAX_EFFICIENCY = 0.28
CONSOLIDATION_MIN_EDGE_TOUCHES = 2
CONSOLIDATION_MIN_CONTAINMENT = 0.72
CONSOLIDATION_MIN_QUALITY = 76
CONSOLIDATION_BREAK_BUFFER_ATR = 0.08
CONSOLIDATION_BREAK_MIN_BODY_ATR = 0.35
CONSOLIDATION_MIN_STRENGTH_GAP = 0.05
CONSOLIDATION_CHART_LOOKBACK = 100
CONSOLIDATION_LIQUIDITY_EDGE_TOL_ATR = 0.12
CONSOLIDATION_LIQUIDITY_LOOKBACK_M15 = 24
CONSOLIDATION_LIQUIDITY_LIFECYCLE_BONUS = 3

ACCUMULATION_DISTRIBUTION_ENABLED = True
AMD_POWER_OF_THREE_ENABLED = True
AMD_RANGE_BARS = 20
AMD_MAX_MANIPULATION_AGE_BARS = 6
AMD_MAX_RANGE_ATR = 5.5
AMD_MAX_RANGE_EFFICIENCY = 0.35
AMD_MIN_EDGE_TOUCHES = 2
AMD_MIN_SWEEP_ATR = 0.08
AMD_BREAK_BUFFER_ATR = 0.08
AMD_BREAK_BODY_ATR = 0.50
AMD_MIN_STRENGTH_GAP = 0.06
AMD_CHART_IMAGES_ENABLED = True
AMD_CHART_LOOKBACK = 48
MOVEMENT_PROGRESS_ENABLED = True
MOVEMENT_PROGRESS_MIN_STRENGTH_GAP = 0.03
MOVEMENT_PULLBACK_MAX_OPPOSITE_STRENGTH = 0.03
MOVEMENT_PROGRESS_MIN_TARGET_ATR = 0.8
MOVEMENT_PROGRESS_MIN_REPORT_PCT = 15
MOVEMENT_PROGRESS_MIN_CHANGE_PCT = 8
# Внутренний кандидат живёт только 1.5 часа: этого достаточно для согласования
# закрытых M15/H1, но старый сценарий уже не участвует в свежей агрегации.
# Это НЕ задержка исходной карточки и не разрешение позднего входа.
SIGNAL_CANDIDATE_TTL_HOURS = 1.5
# Одно предупреждение перед структурной целью; промежуточные проценты не спамят.
SIGNAL_NEAR_TARGET_PCT = 85
# Экстремумы H4/D1 ближе этого расстояния объединяются в одну цель TR.
MOVEMENT_TARGET_MERGE_ATR = 0.15
# TR1 closer than this H1 ATR fraction is part of the entry/reaction zone, not a milestone.
NAVIGATOR_MIN_TR1_ATR = 0.60
NAVIGATOR_TARGET_MIN_GAP_ATR = 0.35
# Fresh-entry quality: a correct direction is not automatically a good new entry.
SIGNAL_MIN_FINAL_TR1_ATR = 0.60
SIGNAL_MIN_FINAL_ROUTE_ATR = 1.35
SIGNAL_MAX_TREND_MATURITY_ATR = 3.20
SIGNAL_MAX_SOURCE_DISPLACEMENT_ATR = 1.80
LIQUIDITY_SWEEP_ENABLED = True
LIQUIDITY_MIN_SWEEP_ATR = 0.08
LIQUIDITY_EQUAL_TOLERANCE_ATR = 0.20
LIQUIDITY_CHOCH_LOOKBACK = 5
LIQUIDITY_CHOCH_BUFFER_ATR = 0.05
LIQUIDITY_CONFIRM_BODY_ATR = 0.35
LIQUIDITY_MAX_CONFIRM_BARS = 6
LIQUIDITY_INVALIDATION_ATR = 0.15
LIQUIDITY_MIN_STRENGTH_GAP = 0.05
# POC / TPO price-acceptance profile (spot FX OHLC proxy, not centralized exchange volume)
POC_ENABLED = True
POC_LOOKBACK_H1 = 72
POC_PROFILE_BINS = 48
POC_VALUE_AREA = 0.70
POC_TOUCH_ATR = 0.12
POC_CONFIRM_BODY_ATR = 0.22
POC_MIN_STRENGTH_GAP = 0.04
POC_MAX_ENTRY_DISTANCE_ATR = 0.65
POC_CHART_IMAGES_ENABLED = True
POC_CHART_LOOKBACK = 72
# VWAP/POC lifecycle. A true VWAP is used ONLY when the provider supplies
# positive volume for the actual candles. Physical FX Twelve Data normally
# supplies OHLC without volume, so the bot must not manufacture a fake VWAP.
VALUE_LIFECYCLE_ENABLED = True
VALUE_APPROACH_ATR = 0.30
VALUE_RETEST_LOOKBACK = 6
# Conservative lifecycle: first touch is context only; direction requires a later retest.
VALUE_REQUIRE_RETEST = True
# If real provider-volume VWAP exists and sits near POC, use only a small quality bonus.
VALUE_POC_VWAP_CONFLUENCE_ATR = 0.20
VALUE_REQUIRE_STRUCTURE_CONFIRM = True

ORDER_BLOCK_ENABLED = True
ORDER_BLOCK_PIVOT_BARS = 3
ORDER_BLOCK_BOS_BUFFER_ATR = 0.08
ORDER_BLOCK_IMPULSE_BODY_ATR = 0.75
ORDER_BLOCK_SEARCH_BACK = 7
ORDER_BLOCK_REACTION_BODY_ATR = 0.30
ORDER_BLOCK_INVALIDATION_ATR = 0.12
ORDER_BLOCK_MAX_RETEST_H1_BARS = 24
ORDER_BLOCK_MIN_STRENGTH_GAP = 0.05
ORDER_BLOCK_REQUIRE_LTF_STRUCTURE = True
ORDER_BLOCK_REACTION_MAX_TOUCH_AGE = 3
# Breaker Block получает только реально пробитые Order Blocks и ждёт обратный ретест.
BREAKER_BLOCK_ENABLED = True
BREAKER_BLOCK_REACTION_BODY_ATR = 0.25
BREAKER_BLOCK_INVALIDATION_ATR = 0.18
BREAKER_BLOCK_MAX_RETEST_M15_BARS = 32
BREAKER_BLOCK_MIN_STRENGTH_GAP = 0.05

# Mitigation Block — context layer only; never an independent Telegram signal.
MITIGATION_BLOCK_ENABLED = True
MITIGATION_BLOCK_SWEEP_LOOKBACK = 6
MITIGATION_BLOCK_SEARCH_BACK = 8
MITIGATION_BLOCK_DISPLACEMENT_BODY_ATR = 0.75
MITIGATION_BLOCK_CONTEXT_BONUS = 2
PHASE_RANGE_BARS = 24
PHASE_PRIOR_BARS = 16
PHASE_MAX_WIDTH_ATR = 7.5
PHASE_MAX_EFFICIENCY = 0.32
PHASE_MIN_PRIOR_MOVE_ATR = 1.8
PHASE_MIN_QUALITY = 74
PHASE_EXIT_STRENGTH_GAP = 0.05
# Сам диапазон рассчитывается внутри; наружу идёт только подтверждённый выход.
PHASE_NOTIFY_FORMATION = False
PHASE_CHART_IMAGES_ENABLED = True
PHASE_CHART_LOOKBACK = 120
DAILY_HIGH_LOW_ENABLED = True
DAILY_HIGH_LOW_CHART_IMAGES_ENABLED = True
DAILY_LEVEL_CHART_LOOKBACK = 60
DAILY_LEVEL_BREAK_BUFFER_ATR = 0.08
DAILY_LEVEL_TOUCH_ATR = 0.12
DAILY_LEVEL_MIN_CONFIRMATIONS = 2
DAILY_LEVEL_MIN_STRENGTH_GAP = 0.05
# PDH/PDL: previous-day external liquidity context for Master Direction.
PDH_PDL_CONTEXT_ENABLED = True
PDH_PDL_SWEEP_LOOKBACK_H1 = 12
PDH_PDL_NEAR_ATR = 1.0
PDH_PDL_SWEEP_BONUS = 4
PDH_PDL_UNSWEPT_PENALTY = 2
CHAIN_ENTRIES_ENABLED = True
CHAIN_PIVOT_BARS = 3
CHAIN_BOS_BUFFER_ATR = 0.08
CHAIN_BOS_BODY_ATR = 0.45
CHAIN_RETEST_TOLERANCE_ATR = 0.22
CHAIN_INVALIDATION_ATR = 0.32
CHAIN_MAX_RETEST_BARS = 12
CHAIN_MIN_CONFIRMATIONS = 2
CHAIN_MIN_STRENGTH_GAP = 0.06
CHAIN_CHART_IMAGES_ENABLED = True
CHAIN_CHART_LOOKBACK = 96
RETEST_CONFIRMATION_ENABLED = True
RETEST_PIVOT_BARS = 3
RETEST_BOS_BUFFER_ATR = 0.08
RETEST_BOS_BODY_ATR = 0.50
RETEST_HOLD_BUFFER_ATR = 0.08
RETEST_TOUCH_TOLERANCE_ATR = 0.18
RETEST_REACTION_BODY_ATR = 0.30
RETEST_INVALIDATION_ATR = 0.18
RETEST_MAX_H1_BARS = 12
RETEST_MIN_STRENGTH_GAP = 0.05
FIBONACCI_ENABLED = True
FIBONACCI_MIN_IMPULSE_ATR = 2.0
FIBONACCI_REACTION_BODY_ATR = 0.30
FIBONACCI_MIN_STRENGTH_GAP = 0.05
FIBONACCI_CHART_IMAGES_ENABLED = True
FIBONACCI_CHART_LOOKBACK = 60
PATTERN_MIN_QUALITY = 72
PATTERN_MIN_CONFIDENCE = 70
PATTERN_LOOKBACK = {"W1": 80, "D1": 150, "H4": 180, "H1": 180, "M15": 160, "M5": 140}
PATTERN_PIVOT = {"W1": 3, "D1": 3, "H4": 3, "H1": 2, "M15": 2, "M5": 2}
# Допуски Фибоначчи для гармонических и ABCD.
FIB_TOL = 0.06
HARMONIC_RATIOS = {
    "gartley": {"xb": (0.56, 0.66), "ac": (0.382, 0.886), "bd": (1.13, 1.618), "xd": (0.72, 0.85)},
    "bat": {"xb": (0.382, 0.50), "ac": (0.382, 0.886), "bd": (1.618, 2.618), "xd": (0.82, 0.95)},
    "alt_bat": {"xb": (0.382, 0.382), "ac": (0.382, 0.886), "bd": (2.0, 3.618), "xd": (1.08, 1.18)},
    "butterfly": {"xb": (0.76, 0.81), "ac": (0.382, 0.886), "bd": (1.618, 2.24), "xd": (1.20, 1.50)},
    "crab": {"xb": (0.382, 0.618), "ac": (0.382, 0.886), "bd": (2.24, 3.618), "xd": (1.55, 1.68)},
    "deep_crab": {"xb": (0.84, 0.924), "ac": (0.382, 0.886), "bd": (2.0, 3.618), "xd": (1.55, 1.68)},
    "shark": {"xb": (0.382, 0.618), "ac": (1.13, 1.618), "xd": (0.86, 1.13)},
    "cypher": {"xb": (0.382, 0.618), "ac": (1.13, 1.414), "xd": (0.75, 0.81)},
    "five_o": {"xb": (1.13, 1.618), "ac": (1.618, 2.24), "cd": (0.48, 0.62)},
    "abcd": {"bc": (0.382, 0.886), "cd_ab": (1.0, 1.68)},
}
ABCD_TIME_SYM = 0.45
PATTERN_MAIN_TFS = ["W1", "D1", "H4", "H1"]
PATTERN_CONFIRM_TFS = ["M15", "M5"]
PATTERN_CHART_IMAGES_ENABLED = True
PATTERN_CHART_LOOKBACK = 55
PATTERN_CHART_BREAK_BUFFER_ATR = 0.05
PATTERN_CHART_BREAK_MIN_BODY_ATR = 0.35
PATTERN_NEWS_BEFORE_MINUTES = 60
PATTERN_NEWS_AFTER_MINUTES = 30
# Structural pattern late-entry/residual-potential guard.
PATTERN_LATE_MIN_REMAINING_ATR = 0.45
PATTERN_LATE_MIN_REMAINING_RATIO = 0.35
PATTERN_LATE_MAX_REALIZED_RATIO = 0.65
# 1-2-3 lifecycle (AGP123R-compatible, integrated into the existing Pattern Scanner).
PATTERN_123_ATR_LENGTH = 14
PATTERN_123_MIN_P1_P2_ATR = 0.65
PATTERN_123_P3_MIN_RETRACE = 0.30
PATTERN_123_P3_MAX_RETRACE = 0.85
PATTERN_123_P3_HOLD_ATR = 0.05
PATTERN_123_BREAK_BUFFER_ATR = 0.05
PATTERN_123_INVALIDATION_ATR = 0.05
PATTERN_123_RETEST_POCKET_ATR = 0.20
# Head & Shoulders geometry. ATR-normalized so the same rules work on W1/D1/H4/H1.
PATTERN_HS_SHOULDER_TOL_ATR = 0.75
PATTERN_HS_HEAD_MIN_ATR = 0.35
PATTERN_HS_MAX_TIME_RATIO = 3.0
# Гармоническая геометрия сама по себе не является торговым сигналом.
# Для отправки требуется подтвержденный импульс H1 и слом структуры M15,
# поддержанные относительной силой валют.
HARMONIC_MIN_STRENGTH_GAP = 0.05
HARMONIC_CONFIRM_BODY_ATR = 0.35
HARMONIC_CONFIRM_LOOKBACK = 8

RETEST_CHART_ENABLED = True
ORDER_BLOCK_CHART_IMAGES_ENABLED = True
ORDER_BLOCK_CHART_LOOKBACK = 72
BREAKER_BLOCK_CHART_IMAGES_ENABLED = True
BREAKER_BLOCK_CHART_LOOKBACK = 72
LIQUIDITY_SWEEP_CHART_IMAGES_ENABLED = True
LIQUIDITY_SWEEP_CHART_LOOKBACK = 72
# Navigator Time Horizon Engine: вероятностное окно, не таймер закрытия сделки.
NAVIGATOR_TIME_HORIZON_ENABLED = True
NAVIGATOR_TIME_MIN_SAMPLES = 5
NAVIGATOR_TIME_PULLBACK_MAX_H1 = 4
NAVIGATOR_TIME_LOCAL_MAX_H1 = 3
NAVIGATOR_TIME_IMPULSE_MAX_H1 = 6
NAVIGATOR_MACRO_HORIZON_ENABLED = True  # Trade Horizon != Macro Direction Horizon

# Echo V4 — News Risk Layer
ECHO_NEWS_RISK_ENABLED = True
ECHO_NEWS_HIGH_PENALTY = 8
ECHO_NEWS_CONTEXT_DEPENDENT_PENALTY = 12
ECHO_NEWS_MEDIUM_PENALTY = 5

# Smart Money 62-26 — отдельный строгий SMC-модуль.
SMART_MONEY_62_26_ENABLED = True
SMART_MONEY_62_26_CHART_IMAGES_ENABLED = True
SMC_62_26_RETRACE = 0.62
SMC_62_26_ZONE_WIDTH = 0.26
SMC_62_26_SWEEP_ATR = 0.06
SMC_62_26_BOS_ATR = 0.05
SMC_62_26_DISPLACEMENT_ATR = 0.65
SMC_62_26_MIN_STRENGTH_GAP = 0.05
SMC_62_26_SETUP_LOOKBACK_H1 = 6
SMC_62_26_MAX_AGE_M15 = 16
SMC_62_26_INVALIDATION_ATR = 0.12

# CRT / Candle Range Theory — событийный модуль, связанный с AMD.
CRT_CANDLE_RANGE_ENABLED = True
CRT_REFERENCE_LOOKBACK_H1 = 8
CRT_MIN_RANGE_ATR = 0.70
CRT_MAX_RANGE_ATR = 2.80
CRT_MIN_SWEEP_ATR = 0.06
CRT_MID_CONFIRM_ATR = 0.05
CRT_MIN_CONFIRM_BODY_ATR = 0.22
CRT_MAX_SWEEP_AGE_H1 = 3
CRT_MAX_CONFIRM_AGE_H1 = 1
CRT_MIN_STRENGTH_GAP = 0.04
CRT_CHART_IMAGES_ENABLED = True

# Fib + SMC — строгая конфлюэнция Fibonacci и Smart Money Concepts.
FIB_SMC_ENABLED = True
FIB_SMC_CHART_IMAGES_ENABLED = True
FIB_SMC_CHART_LOOKBACK = 72
FIB_SMC_MIN_IMPULSE_ATR = 2.2
FIB_SMC_RETRACE_MIN = 0.618
FIB_SMC_RETRACE_MAX = 0.786
FIB_SMC_OTE_REFERENCE = 0.705
FIB_SMC_DEEP_RETRACE_MAX = 0.85
FIB_SMC_REACTION_LOOKBACK_H1 = 4
FIB_SMC_OB_SEARCH_BACK = 8
FIB_SMC_SWEEP_LOOKBACK_H1 = 6
FIB_SMC_SWEEP_TOLERANCE_ATR = 0.12
FIB_SMC_DISPLACEMENT_ATR = 0.18
FIB_SMC_BOS_LOOKBACK_M15 = 6
FIB_SMC_BOS_BUFFER_ATR = 0.03
FIB_SMC_MIN_STRENGTH_GAP = 0.05
FIB_SMC_NEWS_FILTER_ENABLED = True
FIB_SMC_NEWS_BEFORE_MINUTES = 30
FIB_SMC_NEWS_AFTER_MINUTES = 15

# ATS Reversal Point — event-driven only; candidates are tracked silently.
ATS_REVERSAL_ENABLED = True
ATS_REVERSAL_SWEEP_ATR = 0.08
ATS_REVERSAL_WICK_BODY_RATIO = 1.25
ATS_REVERSAL_TRIGGER_LOOKBACK = 5
ATS_REVERSAL_MAX_M15_BARS = 8
ATS_REVERSAL_INVALIDATION_ATR = 0.12
ATS_REVERSAL_CONFIRM_BODY_ATR = 0.12

# Internal HTF -> LTF confirmation handshake. No standalone Telegram alerts.
LTF_CONFIRM_ENABLED = True
LTF_CONFIRM_TIMEFRAMES = ("M15", "M5")
LTF_CONFIRM_LOOKBACK = 40
LTF_CONFIRM_STRUCTURE_BARS = 6
LTF_CONFIRM_DISPLACEMENT_ATR = 0.55
LTF_CONFIRM_MIN_SCORE = 2
LTF_CONFIRM_ALIGN_BONUS = 5
LTF_CONFIRM_CONFLICT_PENALTY = 5


# Balanced Price Range — зона копится молча; карточка только после реакции + OHLC
# и только через общий контур Master / Navigator, не отдельным входом.
BPR_ENABLED = True
BPR_TIMEFRAMES = ("H1", "M15", "M5")
BPR_LOOKBACK = 80
BPR_MAX_AGE_BARS = 24
BPR_MIN_FVG_ATR = 0.06
BPR_MIN_OVERLAP_ATR = 0.04
BPR_TOUCH_BUFFER_ATR = 0.10
BPR_MIN_DIRECTIONAL_BARS = 3
BPR_EQUIVALENT_MOVE_ATR = 0.85
BPR_CHART_IMAGES_ENABLED = True
BPR_ALIGN_BONUS = 4
BPR_CONFLICT_PENALTY = 4


# Propulsion Block — internal continuation confluence only; no standalone alerts.
PROPULSION_ENABLED = True
PROPULSION_TIMEFRAMES = ("H1", "M15")
PROPULSION_LOOKBACK = 60
PROPULSION_STRUCTURE_BARS = 6
PROPULSION_DISPLACEMENT_ATR = 0.65
PROPULSION_MIN_BLOCK_ATR = 0.12
PROPULSION_MAX_AGE_BARS = 18
PROPULSION_TOUCH_BUFFER_ATR = 0.10
PROPULSION_INVALIDATION_ATR = 0.08
PROPULSION_ALIGN_BONUS = 4
PROPULSION_CONFLICT_PENALTY = 4


# CHOCH — internal market-structure confirmation only; no standalone alerts.
CHOCH_ENABLED = True
CHOCH_TIMEFRAMES = ("H1", "M15", "M5")
CHOCH_LOOKBACK = 70
CHOCH_SWING_BARS = 4
CHOCH_DISPLACEMENT_ATR = 0.55
CHOCH_CLOSE_BUFFER_ATR = 0.05
CHOCH_ALIGN_BONUS = 5
CHOCH_CONFLICT_PENALTY = 6


# ERL — External Range Liquidity (internal only)
ERL_ENABLED = True
ERL_TIMEFRAMES = ("H4", "H1")
ERL_LOOKBACK = 40
ERL_OVERSHOOT_ATR = 0.20
ERL_ALIGN_BONUS = 3
ERL_CONFLICT_PENALTY = 3

# Shared IRL/ERL Liquidity Context — internal only, no Telegram module.
LIQUIDITY_CONTEXT_ENABLED = True
LIQUIDITY_CONTEXT_TIMEFRAMES = ("H4", "H1")
LIQUIDITY_CONTEXT_LOOKBACK = 40
LIQUIDITY_CONTEXT_ERL_NEAR_ATR = 0.35
LIQUIDITY_CONTEXT_OPEN_BONUS = 3

# Premium / Discount / Equilibrium (internal only)
PD_ENABLED = True
PD_LOOKBACK = 48
PD_EQ_BAND = 0.08
PD_ALIGN_BONUS = 2
PD_CONFLICT_PENALTY = 2

# MSS — отдельный строгий внутренний Market Structure Shift; без standalone-спама.
MSS_ENABLED = True
MSS_TIMEFRAMES = ("H1", "M15", "M5")
MSS_LOOKBACK = 80
MSS_SWING_BARS = 5
MSS_DISPLACEMENT_ATR = 0.85
MSS_CLOSE_BUFFER_ATR = 0.08
MSS_MIN_BODY_RATIO = 0.55
MSS_ALIGN_BONUS = 6
MSS_CONFLICT_PENALTY = 7

# Market Regime Controller — weights context, never direction by itself.
REGIME_HIGH_VOL_RATIO = 1.45
REGIME_TREND_EFF = 0.48
REGIME_RANGE_EFF = 0.24
REGIME_RANGE_PENALTY = 3
REGIME_HIGH_VOL_PENALTY = 2

# ICT Silver Bullet — внутрисессионный execution-модуль.
# Он может быть источником для Master/Navigator, но не голосует отдельно в Echo/Next Pivot/Briefing:
# иначе один и тот же sweep/displacement/FVG был бы посчитан дважды как направление сессии.
# Окна задаются по New York и автоматически учитывают DST.
SILVER_BULLET_ENABLED = True
SILVER_BULLET_WINDOWS_NY = ((3, 4), (10, 11), (14, 15))
SILVER_BULLET_MIN_STRENGTH_GAP = 0.05
SILVER_BULLET_MIN_FVG_ATR = 0.08
SILVER_BULLET_MIN_DISPLACEMENT_ATR = 0.55
SILVER_BULLET_MAX_SETUP_AGE_M5 = 12
SILVER_BULLET_NEWS_BLOCK_MINUTES = 60
SILVER_BULLET_CHART_IMAGES_ENABLED = True
SILVER_BULLET_CHART_LOOKBACK = 72

# Unified BSL/SSL Liquidity Map — internal shared SMC context; no standalone alerts.
LIQUIDITY_MAP_ENABLED = True
LIQUIDITY_MAP_EQUAL_TOLERANCE_ATR = 0.20
LIQUIDITY_MAP_MERGE_ATR = 0.16
LIQUIDITY_MAP_APPROACH_ATR = 0.35
LIQUIDITY_MAP_STATUS_LOOKBACK_M15 = 16
LIQUIDITY_LEVELS_MIN_STRENGTH = 68
LIQUIDITY_MAP_EQUAL_TOLERANCE_ATR_H4 = 0.16
LIQUIDITY_MAP_EQUAL_TOLERANCE_ATR_H1 = 0.18
LIQUIDITY_MAP_EQUAL_TOLERANCE_ATR_M15 = 0.20

# Global new-signal significance gate (ZIP 29 refinement).
# Detectors still see/store every event internally. Telegram gets a NEW trade
# signal only when there is enough estimated H1 life AND enough price travel.
# Общий слой фактов: склейка модулей, подпись отката, запрет позднего входа.
SIGNAL_CONTEXT_ENABLED = True
CONTEXT_MIN_JUNIOR_AGREE = 2
CONTEXT_MIN_DIRECTED_GAP = 0.03
CONTEXT_ALLOW_LABELED_PULLBACK = True
CONTEXT_PULLBACK_MAX_PROGRESS_PCT = 25
CONTEXT_PULLBACK_MAX_OPPOSITE_GAP = 0.12

SIGNAL_SIGNIFICANCE_GATE_ENABLED = True
SIGNAL_MIN_REMAINING_H1 = 3
# A strong fresh OHLC/displacement event must not wait for another H1 candle.
SIGNAL_EARLY_OHLC_SCORE = 68
# If a source explicitly carries its close time, never present it as a NEW entry
# after more than ~1.25 trigger candles have elapsed. Existing routes are only managed.
SIGNAL_SOURCE_FRESHNESS_ENABLED = True
SIGNAL_SOURCE_MAX_CANDLES_AGE = 1.25
SIGNAL_MIN_ROUTE_ATR = 0.75
SIGNAL_MIN_MEDIAN_H1_BODY_ATR = 0.18
SIGNAL_STRONG_ROUTE_ATR_OVERRIDE = 1.25
SIGNAL_RANGE_EFFICIENCY_FLOOR = 0.18

# Ранний вход: новый сигнал не после уже состоявшегося крупного слива.
# Импульс на текущей или предыдущей H1 — рано. Импульс 2+ бара назад
# и цена уже далеко от его origin — поздно, в том числе для паттернов.
EARLY_ENTRY_GATE_ENABLED = True
EARLY_IMPULSE_MIN_BODY_ATR = 1.15
EARLY_IMPULSE_MIN_RANGE_ATR = 1.30
EARLY_IMPULSE_LOOKBACK_H1 = 10
EARLY_IMPULSE_MAX_AGE_BARS = 1
EARLY_MAX_TRAVEL_ATR = 1.35
EARLY_ORIGIN_RETEST_ATR = 0.40

# Unified OHLC movement layer (ZIP 30 -> 31). Internal filter, never a standalone alert.
OHLC_MOVEMENT_FILTER_ENABLED = True
OHLC_LOOKBACK_BARS = 6
OHLC_WEAK_REVERSAL_MAX_TAIL_ATR = 0.55
OHLC_PRIOR_MOVE_MIN_ATR = 0.70

# Unified market-context layer (internal, no Telegram alerts)
MARKET_STATE_ENABLED = True
EXHAUSTION_ENABLED = True
LIQUIDITY_NARRATIVE_ENABLED = True
REGIME_COMPRESSION_VOL_RATIO = 0.78
REGIME_EXPANSION_VOL_RATIO = 1.22

# Quasimodo Engine — scenario reversal; zone formation is internal only.
QUASIMODO_ENABLED = True
QUASIMODO_TIMEFRAMES = ("H1", "M15", "M5")
QUASIMODO_LOOKBACK = 100
QUASIMODO_PIVOT_BARS = 2
QUASIMODO_MAX_AGE_BARS = 30
QUASIMODO_MIN_SWEEP_ATR = 0.10
QUASIMODO_MSS_DISPLACEMENT_ATR = 0.70
QUASIMODO_ZONE_ATR = 0.16
QUASIMODO_INVALIDATION_ATR = 0.10
QUASIMODO_MIN_DIRECTIONAL_BARS = 3
QUASIMODO_EQUIVALENT_MOVE_ATR = 0.85
QUASIMODO_CHART_IMAGES_ENABLED = True

# CISD (Change in State of Delivery) — internal early delivery-shift context.
# Never a standalone Telegram source; correlated with MSS/BOS as one family.
CISD_ENABLED = True
CISD_TIMEFRAMES = ("H1", "M15", "M5")
CISD_LOOKBACK = 60
CISD_DELIVERY_BARS = 4
CISD_SWEEP_LOOKBACK = 8
CISD_ANCHOR_MAX_AGE = 6
CISD_CLOSE_BUFFER_ATR = 0.03
CISD_MIN_BODY_ATR = 0.35
CISD_MIN_BODY_RATIO = 0.50
CISD_MIN_SWEEP_ATR = 0.03

# Shared Zone Reaction Confirmation (internal shared layer; no Telegram module)
ZONE_REACTION_MAX_TOUCH_AGE = 2
ZONE_REACTION_SWEEP_LOOKBACK = 3
ZONE_REACTION_RECLAIM_BUFFER_ATR = 0.03
ZONE_REACTION_RECOVERY_BODY_FRACTION = 0.50

IMBALANCE_REACTION_MIN_DIRECTIONAL_BARS = 3
IMBALANCE_REACTION_EQUIVALENT_MOVE_ATR = 0.85

# KILLER meta-selector — rare high-convergence setups only.
KILLER_ENABLED = True
KILLER_HUNTER_ENABLED = True  # active scan of all pairs/sides; execution gates remain strict
# 84 вместо 88: тот же класс сетапа, чуть больше проходов по баллу.
# Пол независимости не трогаем — по-прежнему 5 разных семейств.
KILLER_SCORE_THRESHOLD = 84
# KILLER has a stricter hard news veto than ordinary entries. Reuse the shared
# economic calendar; never create a second calendar/feed. Both currencies of
# the pair are checked for HIGH-impact events.
KILLER_NEWS_GUARD_ENABLED = True
KILLER_NEWS_BLOCK_BEFORE_MINUTES = 120
KILLER_NEWS_BLOCK_AFTER_MINUTES = 30
KILLER_MIN_FAMILIES = 5
KILLER_CHART_IMAGES_ENABLED = True
# Memory of confirmed families survives Railway restarts when STATE_DIR is set.
KILLER_PERSIST_MEMORY = True
# Meta-card is not competing with its own source modules for the H1 budget.
KILLER_BYPASS_HOURLY_CAP = True

# PO3 x FVG shared scenario context. Internal only; never a Telegram source.
PO3_FVG_CONTEXT_ENABLED = True

# Precision Entry / Entry Refinement: OTE + CE + IOFED are one correlated
# execution/location family. Internal context only; never a standalone alert.
PRECISION_ENTRY_ENABLED = True
PRECISION_ENTRY_OTE_MIN = 0.618
PRECISION_ENTRY_OTE_MAX = 0.786
PRECISION_ENTRY_OTE_REFERENCE = 0.705
PRECISION_ENTRY_MIN_IMPULSE_ATR = 1.20
PRECISION_ENTRY_ZIGZAG_PCT = 0.18
PRECISION_ENTRY_CE_TOLERANCE_ATR = 0.12
PRECISION_ENTRY_READY_SCORE_BONUS = 4.0

# Market Maker Model — internal orchestration context only; never a Telegram detector.
MARKET_MAKER_MODEL_ENABLED = True
MARKET_MAKER_MODEL_CONFIRMED_BONUS = 3.0

# Demand/Supply — shared PD Array context only; never a standalone Telegram signal.
DEMAND_SUPPLY_CONTEXT_ENABLED = True
DEMAND_SUPPLY_TIMEFRAMES = ("H4", "H1")
DEMAND_SUPPLY_SEARCH_BACK = 12
DEMAND_SUPPLY_BOS_LOOKBACK = 6
DEMAND_SUPPLY_MIN_DISPLACEMENT_ATR = 0.75
DEMAND_SUPPLY_STRONG_DISPLACEMENT_ATR = 1.00
DEMAND_SUPPLY_CONTEXT_BONUS = 2
DEMAND_SUPPLY_FLIP_BREAK_BODY_ATR = 0.35
DEMAND_SUPPLY_FLIP_STRONG_BREAK_ATR = 0.75
DEMAND_SUPPLY_FLIP_RETEST_MAX_BARS = 3

# Weekly audit patch 78+: conservative context additions.
SIGNAL_PULLBACK_MIN_H1_BARS = 3
SIGNAL_PULLBACK_EQUIVALENT_MOVE_ATR = 0.85
# Early post-signal protection for confirmed Liquidity Sweep routes.
# Three closed M15 candles are required; one candle is never treated as a pullback/cancel.
LIQUIDITY_POST_SIGNAL_M15_CONTROL_ENABLED = True
LIQUIDITY_POST_SIGNAL_M15_COUNTER_BARS = 3
LIQUIDITY_POST_SIGNAL_M15_MIN_ATR = 0.35
LIQUIDITY_POST_SIGNAL_M15_STOP_NEAR_ATR = 0.25
PUMP_DUMP_CONTEXT_ENABLED = True
PUMP_DUMP_IMPULSE_BARS = 3
PUMP_DUMP_MIN_IMPULSE_ATR = 1.35
DIVERGENCE_CONTEXT_ENABLED = True
SESSION_CYCLE_CONTEXT_ENABLED = True
SESSION_CYCLE_ACCUM_MAX_ATR = 1.05
SESSION_CYCLE_EXPANSION_MIN_ATR = 1.35

# Continuation liquidity formation: context-only lifecycle, never a signal/family.
CONTINUATION_LIQUIDITY_CONTEXT_ENABLED = True
CONTINUATION_BOS_BUFFER_ATR = 0.04
CONTINUATION_RANGE_MAX_ATR = 2.20
CONTINUATION_RANGE_NET_ATR = 0.80
CONTINUATION_TRENDLINE_TOL_ATR = 0.18
CONTINUATION_LIQUIDITY_READY_BONUS = 4

# CHOCH lifecycle: CHOCH is an early shift, never an automatic full reversal.
CHOCH_LIFECYCLE_LOOKBACK = 90
CHOCH_LIFECYCLE_EVENT_BARS = 18

# Context package 86+: no standalone signals/families; bounded quality adjustments only.
AUCTION_CONTEXT_ENABLED = True
MULTI_TF_NARRATIVE_ENABLED = True
SETUP_MEMORY_ENABLED = True
SETUP_MEMORY_MIN_SAMPLES = 5

# Turtle / Turtle Soup book-derived breakout lifecycle. Context only: never a
# standalone Telegram source and never an independent KILLER family.
TURTLE_BREAKOUT_CONTEXT_ENABLED = True
TURTLE_MEMORY_LOOKBACK_BARS = 32
TURTLE_LEVEL_TOLERANCE_ATR = 0.10
TURTLE_LEVEL_MATURITY_BARS = 8
TURTLE_REENTRY_MIN_BODY_ATR = 0.45
TURTLE_WYCKOFF_TEST_ENABLED = True
# Pattern failure (Farley-style) is correlated context only, never a signal/family.
PATTERN_FAILURE_CONTEXT_ENABLED = True
PATTERN_FAILURE_LOOKBACK_BARS = 8
PATTERN_FAILURE_RECLAIM_ATR = 0.08
PATTERN_FAILURE_DISPLACEMENT_ATR = 0.40

# Unified trade lifecycle: NEW_ENTRY / MANAGE / WATCH / STAND_DOWN.
# Context only — does not create a strategy or a KILLER family.
TRADE_LIFECYCLE_ENABLED = True
TRADE_LIFECYCLE_USE_NEWS_REGIME = True
TRADE_LIFECYCLE_USE_SESSION_CHARACTER = True
TRADE_LIFECYCLE_BLOCK_ASIA_COMPRESSION = True
TRADE_LIFECYCLE_CORRELATED_USD = True

# Numerical calibration telemetry (OBSERVE_ONLY).
# These settings only control what is recorded/reported. They never alter a verdict.
NUMERICAL_CALIBRATION_ENABLED = True
NUMERICAL_CALIBRATION_SCHEMA = 1
CALIBRATION_MASTER_BUCKETS = (78, 81, 85)
CALIBRATION_KILLER_BUCKETS = (84, 87, 91)
CALIBRATION_PROGRESS_BUCKETS = (0, 20, 35, 45, 101)
CALIBRATION_STRENGTH_BUCKETS = (-1.0, 0.0, 0.03, 0.05, 0.12, 1.0)

# Unified ICT liquidity route: PD -> IDM sweep -> structure -> open ERL. Context only.
ICT_ROUTE_ENABLED = True
ICT_ROUTE_CONFIRM_BONUS = 2
ICT_ROUTE_CONFLICT_PENALTY = 3

# Weekly Rhythm — shared context only; never a standalone signal/KILLER family.
WEEKLY_RHYTHM_ENABLED = True
WEEKLY_RHYTHM_EQ_BAND = 0.08
WEEKLY_RHYTHM_H4_PD_LOOKBACK = 30
WEEKLY_RHYTHM_D1_PD_LOOKBACK = 20
WEEKLY_RHYTHM_RECLAIM_ATR = 0.12
WEEKLY_RHYTHM_EXTREME_RECENT_H4 = 6
WEEKLY_RHYTHM_EXPANSION_REALIZATION = 0.55
WEEKLY_RHYTHM_MATURE_REALIZATION = 0.90
WEEKLY_RHYTHM_DIRECTION_MIN_CONFIDENCE = 68
WEEKLY_RHYTHM_INVALIDATED_CONFIDENCE = 35
WEEKLY_RHYTHM_OVEREXTENDED_REALIZATION = 1.15
WEEKLY_RHYTHM_CHART_IMAGES_ENABLED = True

# SMC route lifecycle: a confirmed route bonus requires the source-side
# external liquidity (SSL for LONG / BSL for SHORT) to be swept and reclaimed.
# This strengthens the existing liquidity family; it does not create a signal.
ICT_ROUTE_REQUIRE_SOURCE_SWEEP_RECLAIM = True
ICT_ROUTE_UNRECLAIMED_SOURCE_IS_CONFLICT = True
